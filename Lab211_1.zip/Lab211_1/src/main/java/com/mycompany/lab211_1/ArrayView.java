/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab211_1;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class ArrayView {
    
    private Array array = new Array();
    Scanner scanner = new Scanner(System.in);
    
    public void generateRandomArray() {       
        System.out.println("Enter number of array: ");
        int length = scanner.nextInt();
        array = new Array(length);
    }
    
    public void displayArray(){
        for(int i = 0; i < array.getArray().length;i++){
            System.out.print(array.getArray()[i] + "  ");
        }
    }
    
    public void searchNumber(){
        System.out.println("Enter search value: ");
        int number = scanner.nextInt();
        ArrayList<Integer> temp = new ArrayList<>();
        displayArray();
        for(int i = 0; i<array.getArray().length; i++){
            if(number == array.getArray()[i]){
                temp.add(i);
            }
        }
        if(temp.isEmpty()){
            System.out.println("Number not found");
        } else {
            System.out.print("Found " + number + " at index: ");
            for(int e : temp){
                System.out.print(e + " ");
            }
        }
    }
}
