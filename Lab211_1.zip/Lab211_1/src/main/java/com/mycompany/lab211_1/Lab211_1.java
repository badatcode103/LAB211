/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.lab211_1;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Lab211_1 {

    public static void main(String[] args) {
        
        ArrayView arrayView = new ArrayView();
        
        arrayView.generateRandomArray();
        arrayView.searchNumber();
 
    }
}
