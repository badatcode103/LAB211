/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab211_1;

import java.util.Random;

/**
 *
 * @author ASUS
 */
public class Array {
    
   private int[] array;

    public Array(int length) {
        this.array = new int[length];
        Random random = new Random();
        for(int i=0; i< length; i++){
            this.array[i] = random.nextInt(50-1) + 1;
        }
    }
    
    public Array(){
        
    }
   
    
    public int[] getArray(){
        return array;
    }
 
}
    
    

